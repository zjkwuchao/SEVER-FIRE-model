
Here are the global socio-economic input data used in SEVER-FIRE v1.0

Human population density: popdensglobe

ratio of rural to total population: rurratioglobe

wealth index WI: wealth globe

average distance from cities: distcityglobe 